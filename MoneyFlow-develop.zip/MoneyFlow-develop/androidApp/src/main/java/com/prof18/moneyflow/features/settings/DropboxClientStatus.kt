package com.prof18.moneyflow.features.settings

enum class DropboxClientStatus {
    LINKED,
    NOT_LINKED
}